-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 01, 2026 at 09:59 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `penjualan`
--

-- --------------------------------------------------------

--
-- Table structure for table `barang`
--

CREATE TABLE `barang` (
  `id` int(11) NOT NULL,
  `kode_barang` varchar(10) DEFAULT NULL,
  `nama_barang` varchar(100) DEFAULT NULL,
  `harga` int(11) DEFAULT NULL,
  `stok` int(11) DEFAULT NULL,
  `supplier_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `barang`
--

INSERT INTO `barang` (`id`, `kode_barang`, `nama_barang`, `harga`, `stok`, `supplier_id`) VALUES
(1, 'BRG001', 'Indomie Goreng', 3500, 100, 1),
(2, 'BRG002', 'Aqua 600ml', 4000, 200, 1),
(3, 'BRG003', 'Beras 5kg', 60000, 50, 2),
(4, 'BRG004', 'Gula 1kg', 15000, 80, 2),
(5, 'BRG005', 'Minyak 2L', 30000, 60, 3),
(6, 'BRG006', 'Kopi Kapal Api', 10000, 90, 3),
(7, 'BRG007', 'Teh Botol', 5000, 150, 4),
(8, 'BRG008', 'Susu UHT', 8000, 120, 5),
(9, 'BRG009', 'Sabun Lifebuoy', 6000, 110, 6),
(10, 'BRG010', 'Shampoo Pantene', 25000, 40, 7);

-- --------------------------------------------------------

--
-- Table structure for table `pelanggan`
--

CREATE TABLE `pelanggan` (
  `id` int(11) NOT NULL,
  `nama` varchar(100) DEFAULT NULL,
  `jenis_kelamin` enum('L','P') DEFAULT NULL,
  `telp` varchar(12) DEFAULT NULL,
  `alamat` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `pelanggan`
--

INSERT INTO `pelanggan` (`id`, `nama`, `jenis_kelamin`, `telp`, `alamat`) VALUES
(1, 'Budi', 'L', '0811111111', 'Kamall'),
(2, 'Siti', 'P', '0812222222', 'Bangkalan'),
(3, 'Ahmad', 'L', '0813333333', 'Surabaya'),
(4, 'Dewi', 'P', '0814444444', 'Gresik'),
(5, 'Rudi', 'L', '0815555555', 'Sidoarjo'),
(6, 'Ani', 'P', '0816666666', 'Madura'),
(7, 'Joko', 'L', '0817777777', 'Lamongan'),
(8, 'Rina', 'P', '0818888888', 'Tuban'),
(9, 'Agus', 'L', '0819999999', 'Mojokerto'),
(10, 'Lina', 'P', '0820000000', 'Surabaya');

-- --------------------------------------------------------

--
-- Table structure for table `pembayaran`
--

CREATE TABLE `pembayaran` (
  `id` int(11) NOT NULL,
  `waktu_bayar` datetime DEFAULT NULL,
  `total` int(11) DEFAULT NULL,
  `metode` enum('TUNAI','TRANSFER','EDC') DEFAULT NULL,
  `transaksi_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `pembayaran`
--

INSERT INTO `pembayaran` (`id`, `waktu_bayar`, `total`, `metode`, `transaksi_id`) VALUES
(1, '2026-11-01 14:27:40', 7000, 'TUNAI', 1),
(2, '2026-11-01 14:27:40', 120000, 'TRANSFER', 2),
(3, '2026-11-01 14:27:40', 45000, 'TUNAI', 3),
(4, '2026-11-01 14:27:40', 60000, 'EDC', 4),
(5, '2026-11-01 14:27:40', 16000, 'TUNAI', 5),
(6, '2026-11-01 14:27:40', 31000, 'TRANSFER', 6),
(7, '2026-11-01 14:27:40', 5000, 'TUNAI', 7),
(8, '2026-11-01 14:27:40', 8000, 'TUNAI', 8),
(9, '2026-11-01 14:27:40', 6000, 'EDC', 9),
(10, '2026-11-01 14:27:40', 25000, 'TUNAI', 10);

-- --------------------------------------------------------

--
-- Table structure for table `supplier`
--

CREATE TABLE `supplier` (
  `id` int(11) NOT NULL,
  `nama` varchar(100) DEFAULT NULL,
  `telp` varchar(12) DEFAULT NULL,
  `alamat` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `supplier`
--

INSERT INTO `supplier` (`id`, `nama`, `telp`, `alamat`) VALUES
(1, 'PT. Maju Bersama', '08123456', 'Surabaya'),
(2, 'PT. Senang Sekali', '081515563', 'Bangkalan'),
(3, 'PT. Segar', '0845454663', 'Surabaya'),
(4, 'PT. Sumber Makmur', '081234567892', 'Gresik'),
(5, 'PT. Jaya Abadi', '081234567893', 'Sidoarjo'),
(6, 'PT. Anugrah', '081234567894', 'Madura'),
(7, 'PT. Berkah', '081234567895', 'Kamal'),
(8, 'PT. Sukses', '081234567896', 'Lamongan'),
(9, 'PT. Utama', '081234567897', 'Tuban'),
(10, 'PT. Mandiri', '081234567898', 'Mojokerto');

-- --------------------------------------------------------

--
-- Table structure for table `transaksi`
--

CREATE TABLE `transaksi` (
  `id` int(11) NOT NULL,
  `waktu_transaksi` date DEFAULT NULL,
  `keterangan` text DEFAULT NULL,
  `total` int(11) DEFAULT NULL,
  `pelanggan_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `transaksi`
--

INSERT INTO `transaksi` (`id`, `waktu_transaksi`, `keterangan`, `total`, `pelanggan_id`) VALUES
(1, '2026-05-01', 'Belanja harian', 7000, 1),
(2, '2026-05-01', 'Stok bulanan', 120000, 2),
(3, '2026-05-02', 'Mingguan', 45000, 3),
(4, '2026-05-02', 'Keperluan toko', 60000, 4),
(5, '2026-05-03', 'Belanja', 16000, 5),
(6, '2026-05-03', 'Belanja', 31000, 6),
(7, '2026-05-04', 'Belanja', 5000, 7),
(8, '2026-05-04', 'Belanja', 8000, 8),
(9, '2026-05-05', 'Belanja', 6000, 9),
(10, '2026-05-05', 'Belanja', 25000, 10);

-- --------------------------------------------------------

--
-- Table structure for table `transaksi_detail`
--

CREATE TABLE `transaksi_detail` (
  `transaksi_id` int(11) NOT NULL,
  `barang_id` int(11) NOT NULL,
  `harga` int(11) DEFAULT NULL,
  `qty` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `transaksi_detail`
--

INSERT INTO `transaksi_detail` (`transaksi_id`, `barang_id`, `harga`, `qty`) VALUES
(1, 1, 3500, 2),
(2, 3, 60000, 2),
(3, 4, 15000, 3),
(4, 5, 30000, 2),
(5, 2, 4000, 4),
(6, 6, 10000, 2),
(6, 7, 5000, 1),
(7, 7, 5000, 1),
(8, 8, 8000, 1),
(9, 9, 6000, 1);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id_user` int(11) NOT NULL,
  `username` varchar(100) DEFAULT NULL,
  `password` varchar(35) DEFAULT NULL,
  `nama` varchar(50) DEFAULT NULL,
  `alamat` varchar(150) DEFAULT NULL,
  `hp` varchar(20) DEFAULT NULL,
  `level` tinyint(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id_user`, `username`, `password`, `nama`, `alamat`, `hp`, `level`) VALUES
(1, 'admin', 'admin123', 'Admin', 'Kamal', '0810000001', 1),
(2, 'kasir1', 'kasir123', 'Kasir 1', 'Bangkalan', '0810000002', 2),
(3, 'kasir2', 'kasir123', 'Kasir 2', 'Surabaya', '0810000003', 2),
(4, 'user1', 'user123', 'User 1', 'Gresik', '0810000004', 2),
(5, 'user2', 'user123', 'User 2', 'Sidoarjo', '0810000005', 2),
(6, 'user3', 'user123', 'User 3', 'Madura', '0810000006', 2),
(7, 'user4', 'user123', 'User 4', 'Lamongan', '0810000007', 2),
(8, 'user5', 'user123', 'User 5', 'Tuban', '0810000008', 2),
(9, 'user6', 'user123', 'User 6', 'Mojokerto', '0810000009', 2),
(10, 'user7', 'user123', 'User 7', 'Surabaya', '0810000010', 2);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `barang`
--
ALTER TABLE `barang`
  ADD PRIMARY KEY (`id`),
  ADD KEY `supplier_id` (`supplier_id`);

--
-- Indexes for table `pelanggan`
--
ALTER TABLE `pelanggan`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pembayaran`
--
ALTER TABLE `pembayaran`
  ADD PRIMARY KEY (`id`),
  ADD KEY `transaksi_id` (`transaksi_id`);

--
-- Indexes for table `supplier`
--
ALTER TABLE `supplier`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `transaksi`
--
ALTER TABLE `transaksi`
  ADD PRIMARY KEY (`id`),
  ADD KEY `pelanggan_id` (`pelanggan_id`);

--
-- Indexes for table `transaksi_detail`
--
ALTER TABLE `transaksi_detail`
  ADD PRIMARY KEY (`transaksi_id`,`barang_id`),
  ADD KEY `barang_id` (`barang_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id_user`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `barang`
--
ALTER TABLE `barang`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `pelanggan`
--
ALTER TABLE `pelanggan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `pembayaran`
--
ALTER TABLE `pembayaran`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `supplier`
--
ALTER TABLE `supplier`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `transaksi`
--
ALTER TABLE `transaksi`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `barang`
--
ALTER TABLE `barang`
  ADD CONSTRAINT `barang_ibfk_1` FOREIGN KEY (`supplier_id`) REFERENCES `supplier` (`id`);

--
-- Constraints for table `pembayaran`
--
ALTER TABLE `pembayaran`
  ADD CONSTRAINT `pembayaran_ibfk_1` FOREIGN KEY (`transaksi_id`) REFERENCES `transaksi` (`id`);

--
-- Constraints for table `transaksi`
--
ALTER TABLE `transaksi`
  ADD CONSTRAINT `transaksi_ibfk_1` FOREIGN KEY (`pelanggan_id`) REFERENCES `pelanggan` (`id`);

--
-- Constraints for table `transaksi_detail`
--
ALTER TABLE `transaksi_detail`
  ADD CONSTRAINT `transaksi_detail_ibfk_1` FOREIGN KEY (`transaksi_id`) REFERENCES `transaksi` (`id`),
  ADD CONSTRAINT `transaksi_detail_ibfk_2` FOREIGN KEY (`barang_id`) REFERENCES `barang` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
