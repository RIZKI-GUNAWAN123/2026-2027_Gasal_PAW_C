<?php
require 'auth.php';
wajib_login();
$judul = 'Home';

$jml_barang    = $conn->query('SELECT COUNT(*) c FROM barang')->fetch_assoc()['c'];
$jml_pelanggan = $conn->query('SELECT COUNT(*) c FROM pelanggan')->fetch_assoc()['c'];
$jml_transaksi = $conn->query('SELECT COUNT(*) c FROM penjualan')->fetch_assoc()['c'];

include 'layout/header.php';
?>
<div class="jumbotron" style="padding:30px;">
  <h2>Selamat datang, <?= e($_SESSION['nama_user']) ?>!</h2>
  <p>Anda login sebagai <b><?= (int)$_SESSION['level'] === 1 ? 'Owner (level 1)' : 'Kasir (level 2)' ?></b>.</p>
</div>
<div class="row">
  <div class="col-sm-4"><div class="panel panel-primary"><div class="panel-heading">Jumlah Barang</div>
    <div class="panel-body"><h3 style="margin:0"><?= (int)$jml_barang ?></h3></div></div></div>
  <div class="col-sm-4"><div class="panel panel-success"><div class="panel-heading">Jumlah Pelanggan</div>
    <div class="panel-body"><h3 style="margin:0"><?= (int)$jml_pelanggan ?></h3></div></div></div>
  <div class="col-sm-4"><div class="panel panel-info"><div class="panel-heading">Jumlah Transaksi</div>
    <div class="panel-body"><h3 style="margin:0"><?= (int)$jml_transaksi ?></h3></div></div></div>
</div>
<?php include 'layout/footer.php'; ?>
