<?php
require 'auth.php';
wajib_level(1);              // hanya owner
$judul = 'Data Supplier';
$aksi  = $_GET['aksi'] ?? 'list';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        if (($_POST['act'] ?? '') === 'simpan') {
            $id = (int)$_POST['id']; $nama = trim($_POST['nama']);
            $alamat = trim($_POST['alamat']); $telp = trim($_POST['telepon']);
            if ($nama === '') {
                flash('danger', 'Nama wajib diisi.');
            } elseif ($id > 0) {
                $st = $conn->prepare('UPDATE supplier SET nama_supplier=?, alamat=?, telepon=? WHERE id_supplier=?');
                $st->bind_param('sssi', $nama, $alamat, $telp, $id); $st->execute();
                flash('success', 'Data berhasil diubah.');
            } else {
                $st = $conn->prepare('INSERT INTO supplier (nama_supplier, alamat, telepon) VALUES (?,?,?)');
                $st->bind_param('sss', $nama, $alamat, $telp); $st->execute();
                flash('success', 'Data berhasil ditambahkan.');
            }
        } elseif (($_POST['act'] ?? '') === 'hapus') {
            $id = (int)$_POST['id'];
            $st = $conn->prepare('DELETE FROM supplier WHERE id_supplier=?');
            $st->bind_param('i', $id); $st->execute();
            flash('success', 'Data berhasil dihapus.');
        }
    } catch (mysqli_sql_exception $ex) {
        flash('danger', 'Gagal memproses data. Data mungkin sudah dipakai di tabel lain.');
    }
    header('Location: supplier.php'); exit;
}

$edit = ['id_supplier' => 0, 'nama_supplier' => '', 'alamat' => '', 'telepon' => ''];
if ($aksi === 'edit') {
    $st = $conn->prepare('SELECT * FROM supplier WHERE id_supplier=?');
    $id = (int)($_GET['id'] ?? 0); $st->bind_param('i', $id); $st->execute();
    $edit = $st->get_result()->fetch_assoc();
    if (!$edit) { header('Location: supplier.php'); exit; }
}
include 'layout/header.php';
?>
<h3>Data Supplier</h3>
<?php if ($aksi === 'tambah' || $aksi === 'edit'): ?>
  <div class="panel panel-default"><div class="panel-body">
  <form method="post">
    <input type="hidden" name="act" value="simpan">
    <input type="hidden" name="id" value="<?= (int)$edit['id_supplier'] ?>">
    <div class="form-group"><label>Nama Supplier</label>
      <input type="text" name="nama" class="form-control" maxlength="100" required value="<?= e($edit['nama_supplier']) ?>"></div>
    <div class="form-group"><label>Alamat</label>
      <input type="text" name="alamat" class="form-control" maxlength="255" value="<?= e($edit['alamat']) ?>"></div>
    <div class="form-group"><label>Telepon</label>
      <input type="text" name="telepon" class="form-control" maxlength="20" value="<?= e($edit['telepon']) ?>"></div>
    <button class="btn btn-primary">Simpan</button> <a href="supplier.php" class="btn btn-default">Batal</a>
  </form></div></div>
<?php else: ?>
  <p><a href="supplier.php?aksi=tambah" class="btn btn-primary"><span class="glyphicon glyphicon-plus"></span> Tambah Supplier</a></p>
  <table class="table table-bordered table-striped" style="background:#fff">
    <thead><tr><th width="50">No</th><th>Nama</th><th>Alamat</th><th>Telepon</th><th width="160">Aksi</th></tr></thead>
    <tbody>
    <?php $no = 1; $q = $conn->query('SELECT * FROM supplier ORDER BY id_supplier'); while ($r = $q->fetch_assoc()): ?>
      <tr><td><?= $no++ ?></td><td><?= e($r['nama_supplier']) ?></td><td><?= e($r['alamat']) ?></td><td><?= e($r['telepon']) ?></td>
        <td>
          <a class="btn btn-warning btn-xs" href="supplier.php?aksi=edit&id=<?= (int)$r['id_supplier'] ?>">Edit</a>
          <form method="post" style="display:inline" onsubmit="return confirm('Hapus data ini?')">
            <input type="hidden" name="act" value="hapus"><input type="hidden" name="id" value="<?= (int)$r['id_supplier'] ?>">
            <button class="btn btn-danger btn-xs">Hapus</button></form>
        </td></tr>
    <?php endwhile; ?>
    </tbody>
  </table>
<?php endif; ?>
<?php include 'layout/footer.php'; ?>
