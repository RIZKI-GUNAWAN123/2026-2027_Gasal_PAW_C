<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once __DIR__ . '/config/koneksi.php';
function e($s) { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }
function flash($tipe, $pesan) { $_SESSION['flash'] = ['t' => $tipe, 'm' => $pesan]; }
function tampil_flash() {
    if (isset($_SESSION['flash'])) {
        $f = $_SESSION['flash'];
        unset($_SESSION['flash']);
        echo '<div class="alert alert-' . e($f['t']) . '">' . e($f['m']) . '</div>';
    }
}
function wajib_login() {
    if (!isset($_SESSION['id_user'])) {
        header('Location: login.php');
        exit;
    }
}
function wajib_level($levels) {
    wajib_login();
    if (!in_array((int)$_SESSION['level'], (array)$levels, true)) {
        flash('danger', 'Anda tidak memiliki hak akses ke halaman tersebut.');
        header('Location: index.php');
        exit;
    }
}
function tolak_jika_login() {
    if (isset($_SESSION['id_user'])) {
        header('Location: index.php');
        exit;
    }
}
function rupiah($n) { return 'Rp ' . number_format((int)$n, 0, ',', '.'); }
