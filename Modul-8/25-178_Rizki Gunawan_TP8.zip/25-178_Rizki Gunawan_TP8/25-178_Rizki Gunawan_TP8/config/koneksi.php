<?php
// Konfigurasi koneksi database (XAMPP default)
$conn = mysqli_connect('localhost', 'root', '', 'db_penjualan');
if (!$conn) {
    die('Koneksi database gagal: ' . mysqli_connect_error());
}
mysqli_set_charset($conn, 'utf8mb4');
