<?php
require 'auth.php';
wajib_level(1);              // hanya owner
$judul = 'Data User';
$aksi  = $_GET['aksi'] ?? 'list';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        if (($_POST['act'] ?? '') === 'simpan') {
            $id = (int)$_POST['id_user']; $nama = trim($_POST['nama_user']);
            $username = trim($_POST['username']); $pass = $_POST['password'];
            $level = (int)$_POST['level'];
            if ($nama === '' || $username === '' || !in_array($level, [1, 2], true)) {
                flash('danger', 'Data tidak valid.');
            } elseif ($id > 0) {
                if ($pass !== '') {   // password hanya diubah jika diisi
                    $hash = password_hash($pass, PASSWORD_DEFAULT);
                    $st = $conn->prepare('UPDATE user SET nama_user=?, username=?, password=?, level=? WHERE id_user=?');
                    $st->bind_param('sssii', $nama, $username, $hash, $level, $id);
                } else {
                    $st = $conn->prepare('UPDATE user SET nama_user=?, username=?, level=? WHERE id_user=?');
                    $st->bind_param('ssii', $nama, $username, $level, $id);
                }
                $st->execute();
                if ($id === (int)$_SESSION['id_user']) {   // sinkronkan session bila mengubah diri sendiri
                    $_SESSION['nama_user'] = $nama; $_SESSION['username'] = $username; $_SESSION['level'] = $level;
                }
                flash('success', 'Data user berhasil diubah.');
            } else {
                if ($pass === '') { flash('danger', 'Password wajib diisi untuk user baru.'); header('Location: user.php?aksi=tambah'); exit; }
                $hash = password_hash($pass, PASSWORD_DEFAULT);
                $st = $conn->prepare('INSERT INTO user (nama_user, username, password, level) VALUES (?,?,?,?)');
                $st->bind_param('sssi', $nama, $username, $hash, $level); $st->execute();
                flash('success', 'Data user berhasil ditambahkan.');
            }
        } elseif (($_POST['act'] ?? '') === 'hapus') {
            $id = (int)$_POST['id_user'];
            if ($id === (int)$_SESSION['id_user']) {
                flash('danger', 'Anda tidak dapat menghapus akun yang sedang dipakai login.');
            } else {
                $st = $conn->prepare('DELETE FROM user WHERE id_user=?');
                $st->bind_param('i', $id); $st->execute();
                flash('success', 'Data user berhasil dihapus.');
            }
        }
    } catch (mysqli_sql_exception $ex) {
        flash('danger', 'Gagal memproses data. Username mungkin sudah dipakai, atau user sudah memiliki transaksi.');
    }
    header('Location: user.php'); exit;
}

$edit = ['id_user' => 0, 'nama_user' => '', 'username' => '', 'level' => 2];
if ($aksi === 'edit') {
    $st = $conn->prepare('SELECT id_user, nama_user, username, level FROM user WHERE id_user=?');
    $id = (int)($_GET['id'] ?? 0); $st->bind_param('i', $id); $st->execute();
    $edit = $st->get_result()->fetch_assoc();
    if (!$edit) { header('Location: user.php'); exit; }
}
include 'layout/header.php';
?>
<h3>Data User</h3>
<?php if ($aksi === 'tambah' || $aksi === 'edit'): ?>
  <div class="panel panel-default"><div class="panel-body">
  <form method="post" autocomplete="off">
    <input type="hidden" name="act" value="simpan">
    <input type="hidden" name="id_user" value="<?= (int)$edit['id_user'] ?>">
    <div class="form-group"><label>Nama User</label>
      <input type="text" name="nama_user" class="form-control" maxlength="100" required value="<?= e($edit['nama_user']) ?>"></div>
    <div class="form-group"><label>Username</label>
      <input type="text" name="username" class="form-control" maxlength="50" required value="<?= e($edit['username']) ?>"></div>
    <div class="form-group"><label>Password <?= $edit['id_user'] ? '<small class="text-muted">(kosongkan jika tidak diubah)</small>' : '' ?></label>
      <input type="password" name="password" class="form-control" <?= $edit['id_user'] ? '' : 'required' ?>></div>
    <div class="form-group"><label>Level</label>
      <select name="level" class="form-control">
        <option value="1" <?= (int)$edit['level'] === 1 ? 'selected' : '' ?>>1 - Owner</option>
        <option value="2" <?= (int)$edit['level'] === 2 ? 'selected' : '' ?>>2 - Kasir</option>
      </select></div>
    <button class="btn btn-primary">Simpan</button> <a href="user.php" class="btn btn-default">Batal</a>
  </form></div></div>
<?php else: ?>
  <p><a href="user.php?aksi=tambah" class="btn btn-primary"><span class="glyphicon glyphicon-plus"></span> Tambah User</a></p>
  <table class="table table-bordered table-striped" style="background:#fff">
    <thead><tr><th width="50">No</th><th>Nama</th><th>Username</th><th>Level</th><th width="160">Aksi</th></tr></thead>
    <tbody>
    <?php $no = 1; $q = $conn->query('SELECT id_user, nama_user, username, level FROM user ORDER BY id_user'); while ($r = $q->fetch_assoc()): ?>
      <tr><td><?= $no++ ?></td><td><?= e($r['nama_user']) ?></td><td><?= e($r['username']) ?></td>
        <td><?= (int)$r['level'] === 1 ? 'Owner' : 'Kasir' ?></td>
        <td>
          <a class="btn btn-warning btn-xs" href="user.php?aksi=edit&id=<?= (int)$r['id_user'] ?>">Edit</a>
          <form method="post" style="display:inline" onsubmit="return confirm('Hapus user ini?')">
            <input type="hidden" name="act" value="hapus"><input type="hidden" name="id_user" value="<?= (int)$r['id_user'] ?>">
            <button class="btn btn-danger btn-xs">Hapus</button></form>
        </td></tr>
    <?php endwhile; ?>
    </tbody>
  </table>
<?php endif; ?>
<?php include 'layout/footer.php'; ?>
