<?php
require 'auth.php';
wajib_level(1);              // hanya owner
$judul = 'Data Barang';
$aksi  = $_GET['aksi'] ?? 'list';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        if (($_POST['act'] ?? '') === 'simpan') {
            $id = (int)$_POST['id_barang']; $nama = trim($_POST['nama_barang']);
            $harga = (int)$_POST['harga'];  $stok = (int)$_POST['stok'];
            if ($nama === '' || $harga < 0 || $stok < 0) {
                flash('danger', 'Data tidak valid.');
            } elseif ($id > 0) {
                $st = $conn->prepare('UPDATE barang SET nama_barang=?, harga=?, stok=? WHERE id_barang=?');
                $st->bind_param('siii', $nama, $harga, $stok, $id); $st->execute();
                flash('success', 'Data barang berhasil diubah.');
            } else {
                $st = $conn->prepare('INSERT INTO barang (nama_barang, harga, stok) VALUES (?,?,?)');
                $st->bind_param('sii', $nama, $harga, $stok); $st->execute();
                flash('success', 'Data barang berhasil ditambahkan.');
            }
        } elseif (($_POST['act'] ?? '') === 'hapus') {
            $id = (int)$_POST['id_barang'];
            $st = $conn->prepare('DELETE FROM barang WHERE id_barang=?');
            $st->bind_param('i', $id); $st->execute();
            flash('success', 'Data barang berhasil dihapus.');
        }
    } catch (mysqli_sql_exception $ex) {
        flash('danger', 'Gagal memproses data. Barang mungkin sudah dipakai pada transaksi.');
    }
    header('Location: barang.php'); exit;
}

$edit = ['id_barang' => 0, 'nama_barang' => '', 'harga' => '', 'stok' => ''];
if ($aksi === 'edit') {
    $st = $conn->prepare('SELECT * FROM barang WHERE id_barang=?');
    $id = (int)($_GET['id'] ?? 0); $st->bind_param('i', $id); $st->execute();
    $edit = $st->get_result()->fetch_assoc();
    if (!$edit) { header('Location: barang.php'); exit; }
}
include 'layout/header.php';
?>
<h3>Data Barang</h3>
<?php if ($aksi === 'tambah' || $aksi === 'edit'): ?>
  <div class="panel panel-default"><div class="panel-body">
  <form method="post">
    <input type="hidden" name="act" value="simpan">
    <input type="hidden" name="id_barang" value="<?= (int)$edit['id_barang'] ?>">
    <div class="form-group"><label>Nama Barang</label>
      <input type="text" name="nama_barang" class="form-control" maxlength="100" required value="<?= e($edit['nama_barang']) ?>"></div>
    <div class="form-group"><label>Harga</label>
      <input type="number" name="harga" class="form-control" min="0" required value="<?= e($edit['harga']) ?>"></div>
    <div class="form-group"><label>Stok</label>
      <input type="number" name="stok" class="form-control" min="0" required value="<?= e($edit['stok']) ?>"></div>
    <button class="btn btn-primary">Simpan</button> <a href="barang.php" class="btn btn-default">Batal</a>
  </form></div></div>
<?php else: ?>
  <p><a href="barang.php?aksi=tambah" class="btn btn-primary"><span class="glyphicon glyphicon-plus"></span> Tambah Barang</a></p>
  <table class="table table-bordered table-striped bg-white" style="background:#fff">
    <thead><tr><th width="50">No</th><th>Nama Barang</th><th>Harga</th><th>Stok</th><th width="160">Aksi</th></tr></thead>
    <tbody>
    <?php $no = 1; $q = $conn->query('SELECT * FROM barang ORDER BY id_barang'); while ($r = $q->fetch_assoc()): ?>
      <tr><td><?= $no++ ?></td><td><?= e($r['nama_barang']) ?></td><td><?= rupiah($r['harga']) ?></td><td><?= (int)$r['stok'] ?></td>
        <td>
          <a class="btn btn-warning btn-xs" href="barang.php?aksi=edit&id=<?= (int)$r['id_barang'] ?>">Edit</a>
          <form method="post" style="display:inline" onsubmit="return confirm('Hapus barang ini?')">
            <input type="hidden" name="act" value="hapus"><input type="hidden" name="id_barang" value="<?= (int)$r['id_barang'] ?>">
            <button class="btn btn-danger btn-xs">Hapus</button></form>
        </td></tr>
    <?php endwhile; ?>
    </tbody>
  </table>
<?php endif; ?>
<?php include 'layout/footer.php'; ?>
