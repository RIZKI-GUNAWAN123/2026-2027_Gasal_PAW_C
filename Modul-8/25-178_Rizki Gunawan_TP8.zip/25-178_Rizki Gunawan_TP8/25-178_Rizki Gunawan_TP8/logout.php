<?php
session_start();
$_SESSION = [];           // UNSET SESSION
session_unset();
session_destroy();
header('Location: login.php');
exit;
