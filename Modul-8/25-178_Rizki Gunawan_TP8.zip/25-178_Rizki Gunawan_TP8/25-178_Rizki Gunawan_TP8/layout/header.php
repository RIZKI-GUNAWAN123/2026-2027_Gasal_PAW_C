<?php
// Dipanggil SETELAH halaman memanggil wajib_login()/wajib_level()
$hal    = basename($_SERVER['PHP_SELF']);
$level  = (int)$_SESSION['level'];
$master = ['barang.php', 'supplier.php', 'pelanggan.php', 'user.php'];
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= e($judul ?? 'Sistem Penjualan') ?> - Sistem Penjualan</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@3.4.1/dist/css/bootstrap.min.css">
<style>
body{padding-top:70px;background:#f5f7fa;}
.navbar-inverse{background:#0b3d7a;border-color:#08305f;}
.navbar-inverse .navbar-nav>li>a,.navbar-inverse .navbar-brand{color:#fff;}
.navbar-inverse .navbar-nav>.active>a,.navbar-inverse .navbar-nav>.open>a,
.navbar-inverse .navbar-nav>li>a:hover{background:#08305f;color:#fff;}
.navbar-inverse .dropdown-menu{background:#fff;}
.navbar-inverse .dropdown-menu>li>a{color:#333;}
.navbar-inverse .dropdown-menu>li>a:hover{background:#eee;}
</style>
</head>
<body>
<nav class="navbar navbar-inverse navbar-fixed-top">
  <div class="container">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#menu">
        <span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span>
      </button>
      <a class="navbar-brand" href="index.php"><span class="glyphicon glyphicon-book"></span> Sistem Penjualan</a>
    </div>
    <div class="collapse navbar-collapse" id="menu">
      <ul class="nav navbar-nav">
        <li class="<?= $hal === 'index.php' ? 'active' : '' ?>"><a href="index.php">Home</a></li>

        <?php if ($level === 1): ?>
        <li class="dropdown <?= in_array($hal, $master) ? 'active' : '' ?>">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown">Data Master <span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li><a href="barang.php">Data Barang</a></li>
            <li><a href="supplier.php">Data Supplier</a></li>
            <li><a href="pelanggan.php">Data Pelanggan</a></li>
            <li><a href="user.php">Data User</a></li>
          </ul>
        </li>
        <?php endif; ?>

        <li class="<?= $hal === 'transaksi.php' ? 'active' : '' ?>"><a href="transaksi.php">Transaksi</a></li>
        <li class="<?= $hal === 'laporan.php' ? 'active' : '' ?>"><a href="laporan.php">Laporan</a></li>
      </ul>

      <ul class="nav navbar-nav navbar-right">
        <li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown"><?= e($_SESSION['nama_user']) ?> <span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li class="dropdown-header"><?= $level === 1 ? 'Owner' : 'Kasir' ?></li>
            <li><a href="logout.php">Logout</a></li>
          </ul>
        </li>
      </ul>
    </div>
  </div>
</nav>
<div class="container">
<?php tampil_flash(); ?>
