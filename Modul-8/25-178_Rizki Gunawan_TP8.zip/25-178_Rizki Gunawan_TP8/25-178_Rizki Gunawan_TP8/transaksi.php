<?php
require 'auth.php';
wajib_level([1, 2]);         // owner & kasir
$judul = 'Transaksi';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $tanggal = $_POST['tanggal'] ?? '';
    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $tanggal)) { $tanggal = date('Y-m-d'); }
    $id_pel = (int)($_POST['id_pelanggan'] ?? 0);

    $items = [];
    foreach (($_POST['id_barang'] ?? []) as $i => $idb) {
        $idb = (int)$idb; $q = (int)($_POST['qty'][$i] ?? 0);
        if ($idb > 0 && $q > 0) { $items[$idb] = ($items[$idb] ?? 0) + $q; }
    }

    if (!$items) {
        flash('danger', 'Pilih minimal satu barang dengan jumlah lebih dari 0.');
    } else {
        $conn->begin_transaction();
        try {
            $total = 0; $rows = [];
            foreach ($items as $idb => $q) {
                $st = $conn->prepare('SELECT nama_barang, harga, stok FROM barang WHERE id_barang=? FOR UPDATE');
                $st->bind_param('i', $idb); $st->execute();
                $b = $st->get_result()->fetch_assoc();
                if (!$b) { throw new Exception('Barang tidak ditemukan.'); }
                if ($b['stok'] < $q) { throw new Exception("Stok {$b['nama_barang']} tidak cukup (sisa {$b['stok']})."); }
                $sub = $b['harga'] * $q; $total += $sub;
                $rows[] = [$idb, $q, (int)$b['harga'], $sub];
            }
            $uid = (int)$_SESSION['id_user'];   // kasir/owner yang sedang login
            $st = $conn->prepare('INSERT INTO penjualan (tanggal, id_pelanggan, id_user, total) VALUES (?,?,?,?)');
            $st->bind_param('siii', $tanggal, $id_pel, $uid, $total); $st->execute();
            $id_penjualan = $conn->insert_id;

            $ins = $conn->prepare('INSERT INTO detail_penjualan (id_penjualan, id_barang, qty, harga, subtotal) VALUES (?,?,?,?,?)');
            $upd = $conn->prepare('UPDATE barang SET stok = stok - ? WHERE id_barang = ?');
            foreach ($rows as [$idb, $q, $harga, $sub]) {
                $ins->bind_param('iiiii', $id_penjualan, $idb, $q, $harga, $sub); $ins->execute();
                $upd->bind_param('ii', $q, $idb); $upd->execute();
            }
            $conn->commit();
            flash('success', 'Transaksi #' . $id_penjualan . ' berhasil disimpan. Total: ' . rupiah($total));
        } catch (Throwable $ex) {
            $conn->rollback();
            flash('danger', 'Transaksi gagal: ' . $ex->getMessage());
        }
    }
    header('Location: transaksi.php'); exit;
}

$barang    = $conn->query('SELECT * FROM barang ORDER BY nama_barang')->fetch_all(MYSQLI_ASSOC);
$pelanggan = $conn->query('SELECT * FROM pelanggan ORDER BY id_pelanggan')->fetch_all(MYSQLI_ASSOC);
include 'layout/header.php';
?>
<h3>Transaksi Penjualan</h3>
<div class="panel panel-default"><div class="panel-body">
<form method="post" id="frm">
  <div class="row">
    <div class="col-sm-4 form-group"><label>Tanggal</label>
      <input type="date" name="tanggal" class="form-control" value="<?= date('Y-m-d') ?>" required></div>
    <div class="col-sm-4 form-group"><label>Pelanggan</label>
      <select name="id_pelanggan" class="form-control" required>
        <?php foreach ($pelanggan as $p): ?>
          <option value="<?= (int)$p['id_pelanggan'] ?>"><?= e($p['nama_pelanggan']) ?></option>
        <?php endforeach; ?>
      </select></div>
    <div class="col-sm-4 form-group"><label>Kasir</label>
      <input type="text" class="form-control" value="<?= e($_SESSION['nama_user']) ?>" readonly></div>
  </div>

  <table class="table table-bordered" id="tbl">
    <thead><tr><th>Barang</th><th width="120">Harga</th><th width="110">Qty</th><th width="140">Subtotal</th><th width="50"></th></tr></thead>
    <tbody></tbody>
    <tfoot><tr><th colspan="3" class="text-right">TOTAL</th><th id="total">Rp 0</th><th></th></tr></tfoot>
  </table>
  <button type="button" class="btn btn-default" id="tambah"><span class="glyphicon glyphicon-plus"></span> Tambah Barang</button>
  <button class="btn btn-primary">Simpan Transaksi</button>
</form>
</div></div>

<template id="row">
  <tr>
    <td><select name="id_barang[]" class="form-control brg">
      <option value="">-- pilih barang --</option>
      <?php foreach ($barang as $b): ?>
        <option value="<?= (int)$b['id_barang'] ?>" data-harga="<?= (int)$b['harga'] ?>" data-stok="<?= (int)$b['stok'] ?>">
          <?= e($b['nama_barang']) ?> (stok <?= (int)$b['stok'] ?>)</option>
      <?php endforeach; ?>
    </select></td>
    <td class="harga text-right">0</td>
    <td><input type="number" name="qty[]" class="form-control qty" min="1" value="1"></td>
    <td class="sub text-right">0</td>
    <td><button type="button" class="btn btn-danger btn-xs hapus">&times;</button></td>
  </tr>
</template>

<script>
const rp = n => 'Rp ' + n.toLocaleString('id-ID');
const body = document.querySelector('#tbl tbody');
function hitung() {
  let total = 0;
  body.querySelectorAll('tr').forEach(tr => {
    const opt = tr.querySelector('.brg').selectedOptions[0];
    const harga = parseInt(opt.dataset.harga || 0), qty = parseInt(tr.querySelector('.qty').value || 0);
    const sub = harga * qty;
    tr.querySelector('.harga').textContent = rp(harga);
    tr.querySelector('.sub').textContent = rp(sub);
    total += sub;
  });
  document.getElementById('total').textContent = rp(total);
}
function tambahBaris() {
  body.appendChild(document.getElementById('row').content.cloneNode(true));
  hitung();
}
document.getElementById('tambah').onclick = tambahBaris;
body.addEventListener('input', hitung);
body.addEventListener('change', hitung);
body.addEventListener('click', e => {
  if (e.target.classList.contains('hapus')) { e.target.closest('tr').remove(); hitung(); }
});
tambahBaris();
</script>
<?php include 'layout/footer.php'; ?>
