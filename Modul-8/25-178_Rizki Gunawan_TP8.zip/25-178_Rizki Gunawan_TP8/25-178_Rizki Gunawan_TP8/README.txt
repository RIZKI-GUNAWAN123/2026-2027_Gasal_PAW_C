MODUL 8: SESSION DAN SECURITY - Sistem Penjualan

CARA PAKAI
1. Salin folder "penjualan" ke C:\xampp\htdocs\
2. Start Apache & MySQL di XAMPP.
3. Import db_penjualan.sql lewat phpMyAdmin (buat database db_penjualan).
4. Buka http://localhost/penjualan/login.php
   (cek koneksi di config/koneksi.php bila user/password MySQL berbeda)

AKUN UJI (sesuai hash di tabel user)
  admin  / admin123  -> level 1 (Owner)
  owner1 / password  -> level 1 (Owner)
  kasir  / kasir123  -> level 2 (Kasir)
  kasir1 / password  -> level 2 (Kasir)

FILE
  auth.php        session_start, wajib_login(), wajib_level(), tolak_jika_login()
  login.php       validasi login (password_verify) + set session
  logout.php      unset & destroy session -> redirect ke login
  index.php       Home
  barang.php, supplier.php, pelanggan.php, user.php   CRUD Data Master (hanya level 1)
  transaksi.php, laporan.php                          Level 1 & 2
  layout/         header (navbar sesuai level) & footer
