<?php
require 'auth.php';
wajib_level([1, 2]);         // owner & kasir
$judul = 'Laporan';

$dari   = $_GET['dari']   ?? date('Y-m-01');
$sampai = $_GET['sampai'] ?? date('Y-m-d');
if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $dari))   { $dari = date('Y-m-01'); }
if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $sampai)) { $sampai = date('Y-m-d'); }

$detail = null; $head = null;
if (isset($_GET['id'])) {
    $id = (int)$_GET['id'];
    $st = $conn->prepare('SELECT p.*, pl.nama_pelanggan, u.nama_user FROM penjualan p
        JOIN pelanggan pl ON pl.id_pelanggan = p.id_pelanggan JOIN user u ON u.id_user = p.id_user
        WHERE p.id_penjualan = ?');
    $st->bind_param('i', $id); $st->execute();
    $head = $st->get_result()->fetch_assoc();
    if ($head) {
        $st = $conn->prepare('SELECT b.nama_barang, d.qty, d.harga, d.subtotal FROM detail_penjualan d
            JOIN barang b ON b.id_barang = d.id_barang WHERE d.id_penjualan = ?');
        $st->bind_param('i', $id); $st->execute();
        $detail = $st->get_result()->fetch_all(MYSQLI_ASSOC);
    }
}

$st = $conn->prepare('SELECT p.id_penjualan, p.tanggal, p.total, pl.nama_pelanggan, u.nama_user
    FROM penjualan p JOIN pelanggan pl ON pl.id_pelanggan = p.id_pelanggan
    JOIN user u ON u.id_user = p.id_user
    WHERE p.tanggal BETWEEN ? AND ? ORDER BY p.tanggal DESC, p.id_penjualan DESC');
$st->bind_param('ss', $dari, $sampai); $st->execute();
$data = $st->get_result()->fetch_all(MYSQLI_ASSOC);
$grand = array_sum(array_column($data, 'total'));

include 'layout/header.php';
?>
<h3>Laporan Penjualan</h3>

<?php if ($head): ?>
<div class="panel panel-info">
  <div class="panel-heading">Detail Transaksi #<?= (int)$head['id_penjualan'] ?></div>
  <div class="panel-body">
    <p>Tanggal: <b><?= e($head['tanggal']) ?></b> &nbsp;|&nbsp; Pelanggan: <b><?= e($head['nama_pelanggan']) ?></b> &nbsp;|&nbsp; Kasir: <b><?= e($head['nama_user']) ?></b></p>
    <table class="table table-bordered" style="background:#fff">
      <thead><tr><th>Barang</th><th>Harga</th><th>Qty</th><th>Subtotal</th></tr></thead>
      <tbody>
      <?php foreach ($detail as $d): ?>
        <tr><td><?= e($d['nama_barang']) ?></td><td><?= rupiah($d['harga']) ?></td><td><?= (int)$d['qty'] ?></td><td><?= rupiah($d['subtotal']) ?></td></tr>
      <?php endforeach; ?>
      </tbody>
      <tfoot><tr><th colspan="3" class="text-right">Total</th><th><?= rupiah($head['total']) ?></th></tr></tfoot>
    </table>
    <a class="btn btn-default btn-sm" href="laporan.php?dari=<?= e($dari) ?>&sampai=<?= e($sampai) ?>">Tutup</a>
  </div>
</div>
<?php endif; ?>

<form class="form-inline" method="get" style="margin-bottom:15px">
  <div class="form-group"><label>Dari</label> <input type="date" name="dari" class="form-control" value="<?= e($dari) ?>"></div>
  <div class="form-group"><label>Sampai</label> <input type="date" name="sampai" class="form-control" value="<?= e($sampai) ?>"></div>
  <button class="btn btn-primary">Tampilkan</button>
</form>

<table class="table table-bordered table-striped" style="background:#fff">
  <thead><tr><th width="50">No</th><th>No. Transaksi</th><th>Tanggal</th><th>Pelanggan</th><th>Kasir</th><th>Total</th><th width="80">Aksi</th></tr></thead>
  <tbody>
  <?php if (!$data): ?><tr><td colspan="7" class="text-center text-muted">Tidak ada data pada periode ini.</td></tr><?php endif; ?>
  <?php $no = 1; foreach ($data as $r): ?>
    <tr><td><?= $no++ ?></td><td>#<?= (int)$r['id_penjualan'] ?></td><td><?= e($r['tanggal']) ?></td>
      <td><?= e($r['nama_pelanggan']) ?></td><td><?= e($r['nama_user']) ?></td><td><?= rupiah($r['total']) ?></td>
      <td><a class="btn btn-info btn-xs" href="laporan.php?dari=<?= e($dari) ?>&sampai=<?= e($sampai) ?>&id=<?= (int)$r['id_penjualan'] ?>">Detail</a></td></tr>
  <?php endforeach; ?>
  </tbody>
  <tfoot><tr><th colspan="5" class="text-right">Total Penjualan</th><th colspan="2"><?= rupiah($grand) ?></th></tr></tfoot>
</table>
<?php include 'layout/footer.php'; ?>
