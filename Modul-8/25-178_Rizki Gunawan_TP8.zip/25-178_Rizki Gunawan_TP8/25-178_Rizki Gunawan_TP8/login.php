<?php
require 'auth.php';
tolak_jika_login();   // sudah login -> tidak boleh ke halaman login

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($username === '' || $password === '') {
        $error = 'Username dan password wajib diisi.';
    } else {
        $st = $conn->prepare('SELECT id_user, nama_user, username, password, level FROM user WHERE username = ?');
        $st->bind_param('s', $username);
        $st->execute();
        $user = $st->get_result()->fetch_assoc();

        if ($user && password_verify($password, $user['password'])) {
            session_regenerate_id(true);               // cegah session fixation
            $_SESSION['id_user']   = (int)$user['id_user']; // SET SESSION
            $_SESSION['nama_user'] = $user['nama_user'];
            $_SESSION['username']  = $user['username'];
            $_SESSION['level']     = (int)$user['level'];
            header('Location: index.php');
            exit;
        }
        $error = 'Username atau password salah.';
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Login - Sistem Penjualan</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@3.4.1/dist/css/bootstrap.min.css">
<style>
body{background:#eef2f7;}
.box{max-width:380px;margin:90px auto;}
.box .head{background:#0b3d7a;color:#fff;padding:18px;border-radius:4px 4px 0 0;text-align:center;font-size:20px;}
.box .body{background:#fff;padding:22px;border:1px solid #d9e0ea;border-top:0;border-radius:0 0 4px 4px;}
</style>
</head>
<body>
<div class="box">
  <div class="head"><span class="glyphicon glyphicon-book"></span> Sistem Penjualan</div>
  <div class="body">
    <?php if ($error): ?><div class="alert alert-danger"><?= e($error) ?></div><?php endif; ?>
    <form method="post" autocomplete="off">
      <div class="form-group"><label>Username</label>
        <input type="text" name="username" class="form-control" value="<?= e($_POST['username'] ?? '') ?>" autofocus></div>
      <div class="form-group"><label>Password</label>
        <input type="password" name="password" class="form-control"></div>
      <button class="btn btn-primary btn-block">Login</button>
    </form>
  </div>
</div>
</body>
</html>
